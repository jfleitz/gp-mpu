Game Plan multi-mpu ROM

Description: 
The game rom images used are from the original release of the title and have not been modified. Modification to the game rom itself is not permitted when using this image.

Filename: gp-mpu.bin
Rom Type: 27c020 / 27c2001 (256kbx8)
Checksum: 0xED90

Used with permission by Game Plan, Inc.
